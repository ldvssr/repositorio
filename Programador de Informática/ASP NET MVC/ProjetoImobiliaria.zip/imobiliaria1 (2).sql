-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 02-Mar-2022 às 17:36
-- Versão do servidor: 10.4.21-MariaDB
-- versão do PHP: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `imobiliaria1`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `receita`
--

CREATE TABLE `receita` (
  `id` int(11) UNSIGNED NOT NULL,
  `ingredientes` varchar(1000) NOT NULL,
  `preparacao` varchar(1500) NOT NULL,
  `nivel_dificuldade` int(11) DEFAULT NULL,
  `tempo_preparacao` int(11) DEFAULT NULL,
  `imagem` varchar(100) DEFAULT NULL,
  `tipo_receita` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `receita`
--

INSERT INTO `receita` (`id`, `ingredientes`, `preparacao`, `nivel_dificuldade`, `tempo_preparacao`, `imagem`, `tipo_receita`) VALUES
(1, 'Matosinhos', '221 R. Silva Pinheiro', 500000, 150, 'moradia.jpg', 5);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_receita`
--

CREATE TABLE `tipo_receita` (
  `id` int(11) UNSIGNED NOT NULL,
  `tipo_receita` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tipo_receita`
--

INSERT INTO `tipo_receita` (`id`, `tipo_receita`) VALUES
(1, 'T0'),
(2, 'T1'),
(3, 'T2'),
(4, 'T3'),
(5, 'T4'),
(6, 'T5');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `receita`
--
ALTER TABLE `receita`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tipo_receita`
--
ALTER TABLE `tipo_receita`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `receita`
--
ALTER TABLE `receita`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `tipo_receita`
--
ALTER TABLE `tipo_receita`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
