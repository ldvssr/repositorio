#include "header.h"
int soma(int a, int b)
{
	return (a+b);
}
