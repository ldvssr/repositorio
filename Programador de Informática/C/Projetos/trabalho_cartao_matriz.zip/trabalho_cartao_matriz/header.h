//bibliotecas + assinaturas das fun��es + estruturas + constantes
#include <stdio.h>
#include <locale.h>
int soma(int a, int b);
